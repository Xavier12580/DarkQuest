#ifndef _UTIL_BEAM__H_
#define _UTIL_BEAM__H_

namespace UtilBeam {
  void ListOfRfValues(int& n_value, int*& list_values);
  void ListOfRfValues(int& n_value, double*& list_values);
}; // namespace UtilBeam

#endif /* _UTIL_BEAM__H_ */
