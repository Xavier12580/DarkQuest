#ifndef PHOOL_PHMESSAGE_H
#define PHOOL_PHMESSAGE_H

#include <string>

void PHMessage(const std::string& functionName, int messageType, const std::string& message);

#endif
