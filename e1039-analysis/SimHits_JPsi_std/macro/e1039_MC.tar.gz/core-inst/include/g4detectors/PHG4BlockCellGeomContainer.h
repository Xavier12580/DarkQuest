#ifndef PHG4BlockCellGeomContainer_H__
#define PHG4BlockCellGeomContainer_H__

#include <phool/PHObject.h>

#include <map>

class PHG4BlockCellGeom;

class PHG4BlockCellGeomContainer: public PHObject
{
 public:
  typedef std::map<int, PHG4BlockCellGeom*> Map;
  typedef Map::iterator Iterator;
  typedef Map::const_iterator ConstIterator;
  typedef std::pair<Iterator, Iterator> Range;
  typedef std::pair<ConstIterator, ConstIterator> ConstRange;

  PHG4BlockCellGeomContainer();
  virtual ~PHG4BlockCellGeomContainer();

  void identify(std::ostream& os = std::cout) const;

  int AddLayerCellGeom(const int i, PHG4BlockCellGeom *mygeom);
  int AddLayerCellGeom(PHG4BlockCellGeom *mygeom);
  PHG4BlockCellGeom *GetLayerCellGeom(const int i);
  int get_NLayers() const {return layergeoms.size();}
  std::pair<std::map<int,PHG4BlockCellGeom *>::const_iterator, std::map<int,PHG4BlockCellGeom *>::const_iterator> get_begin_end() const {return std::make_pair(layergeoms.begin(), layergeoms.end());}

 protected:
  std::map<int,PHG4BlockCellGeom *> layergeoms ;
  ClassDef(PHG4BlockCellGeomContainer,1)
};

#endif
