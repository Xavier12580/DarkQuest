#ifndef PHG4StepStatusDecode_h
#define PHG4StepStatusDecode_h

#include <string>

namespace PHG4StepStatusDecode
{
  std::string GetStepStatus(const int istatus);
}

#endif
